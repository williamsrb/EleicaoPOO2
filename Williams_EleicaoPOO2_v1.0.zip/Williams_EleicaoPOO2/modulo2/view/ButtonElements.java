package modulo2.view;

import javax.swing.JButton;
import javax.swing.JComponent;

public final class ButtonElements extends JComponent {
	private static final long serialVersionUID = 1002L;
	private JButton btnD0;
	private JButton btnD1;
	private JButton btnD2;
	private JButton btnD3;
	private JButton btnD4;
	private JButton btnD5;
	private JButton btnD6;
	private JButton btnD7;
	private JButton btnD8;
	private JButton btnD9;
	private JButton btnCGREEN;
	private JButton btnCRED;
	private JButton btnCWHITE;

	public JButton getBtnD0() {
		return this.btnD0;
	}

	public JButton getBtnD1() {
		return this.btnD1;
	}

	public JButton getBtnD2() {
		return this.btnD2;
	}

	public JButton getBtnD3() {
		return this.btnD3;
	}

	public JButton getBtnD4() {
		return this.btnD4;
	}

	public JButton getBtnD5() {
		return this.btnD5;
	}

	public JButton getBtnD6() {
		return this.btnD6;
	}

	public JButton getBtnD7() {
		return this.btnD7;
	}

	public JButton getBtnD8() {
		return this.btnD8;
	}

	public JButton getBtnD9() {
		return this.btnD9;
	}

	public JButton getBtnCGREEN() {
		return this.btnCGREEN;
	}

	public JButton getBtnCRED() {
		return this.btnCRED;
	}

	public JButton getBtnCWHITE() {
		return this.btnCWHITE;
	}

	JButton setBtnD0(JButton btnD0) {
		return this.btnD0 = btnD0;
	}

	JButton setBtnD1(JButton btnD1) {
		return this.btnD1 = btnD1;
	}

	JButton setBtnD2(JButton btnD2) {
		return this.btnD2 = btnD2;
	}

	JButton setBtnD3(JButton btnD3) {
		return this.btnD3 = btnD3;
	}

	JButton setBtnD4(JButton btnD4) {
		return this.btnD4 = btnD4;
	}

	JButton setBtnD5(JButton btnD5) {
		return this.btnD5 = btnD5;
	}

	JButton setBtnD6(JButton btnD6) {
		return this.btnD6 = btnD6;
	}

	JButton setBtnD7(JButton btnD7) {
		return this.btnD7 = btnD7;
	}

	JButton setBtnD8(JButton btnD8) {
		return this.btnD8 = btnD8;
	}

	JButton setBtnD9(JButton btnD9) {
		return this.btnD9 = btnD9;
	}

	JButton setBtnCGREEN(JButton btnCGREEN) {
		return this.btnCGREEN = btnCGREEN;
	}

	JButton setBtnCRED(JButton btnCRED) {
		return this.btnCRED = btnCRED;
	}

	JButton setBtnCWHITE(JButton btnCWHITE) {
		return this.btnCWHITE = btnCWHITE;
	}
}