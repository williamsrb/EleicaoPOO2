package modulo2.util;

public enum KeyEnum {
	D0, D1, D2, D3, D4, D5, D6, D7, D8, D9, CGREEN, CRED, CWHITE, BACK, ENTER
}