package resources.lib.controller;

public final class FileUpload {
	public static final String uploadPath = "/resources/upload/";
	public static final String imagePath = "/resources/images/";
	public static final String effectPath = "/resources/imageeffects/";
}