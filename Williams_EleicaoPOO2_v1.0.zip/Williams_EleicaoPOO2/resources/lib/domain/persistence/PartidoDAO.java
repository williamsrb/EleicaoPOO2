package resources.lib.domain.persistence;

import resources.lib.domain.Partido;

public interface PartidoDAO extends DAO<Partido> {}