package resources.lib.domain.persistence;

import resources.lib.domain.Deputado;

public interface DeputadoDAO extends DAO<Deputado> {}