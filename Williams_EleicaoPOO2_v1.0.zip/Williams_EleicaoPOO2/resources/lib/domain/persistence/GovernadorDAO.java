package resources.lib.domain.persistence;

import resources.lib.domain.Governador;

public interface GovernadorDAO extends DAO<Governador> {}