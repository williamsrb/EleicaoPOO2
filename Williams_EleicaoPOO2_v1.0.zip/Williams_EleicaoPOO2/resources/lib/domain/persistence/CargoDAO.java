package resources.lib.domain.persistence;

import resources.lib.domain.Cargo;

public interface CargoDAO extends DAO<Cargo> {}