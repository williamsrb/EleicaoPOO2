package resources.lib.domain.persistence;

import resources.lib.domain.Presidente;

public interface PresidenteDAO extends DAO<Presidente> {}