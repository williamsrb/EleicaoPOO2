package resources.lib.other;

public interface Singleton {
	public Object clone() throws CloneNotSupportedException;
}